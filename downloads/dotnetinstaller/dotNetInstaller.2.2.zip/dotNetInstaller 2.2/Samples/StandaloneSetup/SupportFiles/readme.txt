Copy here all the content of the support files directory \Samples\SupportFiles
Download from the internet all the missing components as specified in the SupportFiles directory


