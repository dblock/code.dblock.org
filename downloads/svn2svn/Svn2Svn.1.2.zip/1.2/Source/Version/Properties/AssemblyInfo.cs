﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Version")]
[assembly: Guid("184CC3B9-235F-461c-9070-B93858DB3B24")]
