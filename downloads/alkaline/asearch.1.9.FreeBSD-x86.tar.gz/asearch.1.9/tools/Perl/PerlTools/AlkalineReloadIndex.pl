#!/usr/bin/perl

#
# Alkaline Search Engine Perl API
# http://alkaline.vestris.com
# (c) Vestris Inc. 1994-2001
#

use Carp;
use Alkaline::Server;

@ARGV == 3 || @ARGV == 4 or Carp::croak 'usage: AlkalineReloadIndex [server:port] [user] [pass] <[config]>';

my $asearch_server = Alkaline::Server->new();

$asearch_server->server_port($ARGV[0]);
$asearch_server->user($ARGV[1]);
$asearch_server->pass($ARGV[2]);

print $asearch_server->post_action('reloadindex&config='.$ARGV[3]);
print "\n";
