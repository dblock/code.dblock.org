#!/usr/bin/perl

#
# Alkaline Search Engine Perl API
# http://alkaline.vestris.com
# (c) Vestris Inc. 1994-2001
#

use Carp;
use Alkaline::Server;

@ARGV == 5 or Carp::croak 'usage: AlkalineAddUrl [server:port] [user] [pass] [config] [url]';

my $asearch_server = Alkaline::Server->new();

$asearch_server->server_port($ARGV[0]);
$asearch_server->user($ARGV[1]);
$asearch_server->pass($ARGV[2]);

print $asearch_server->post_action('indexadd&url='.$ARGV[4].'&alias='.$ARGV[3]);
print "\n";
