=head1 NAME

  Alkaline::Server - Alkaline Search Engine manipulators

=head1 SYNOPSIS

  use Alkaline::Server;
  my $as = Alkaline::Server->new();

=head1 DESCRIPTION

  This module implements Alkaline Search Engine manipulator functions.
  Alkaline is (c) Vestris Inc. http://www.vestris.com/alkaline/.

  Available functions:

  $as->server([string])
    get/set the server name on which Alkaline runs
    $as->server('www.foo.com');
    print "Alkaline runs on ".$as->server."\n";

  $as->port([string])
    get/set the port which Alkaline is bound to
    $as->port('9999');
    print "Alkaline runs on port ".$as->port."\n";

  $as->server_port([string])
    get/set both the server and the port
    $as->server_port('www.foo.com:9999');
    print "Alkaline runs on ".$as->server_port."\n";

  $as->user([string])
    get/set the admin user name, default is root

  $as->pass([string])
    get/set the admin password (global.cnf)

  $as->admin([string])
    get/set the admin location, default is admin

  $as->post_action([action])
    perform a post action
    This translates into an HTTP post to http://server:port/admin/ with
    the form ACTION value set to the parameter.

  $as->get_url([url])
    browse to an admin url
    This translates into an HTTP get to http://server:port/admin/url

=head1 AUTHOR

  Vestris Inc. - admin@vestris.com

=head1 SEE ALSO

  perl(1).

=cut

package Alkaline::Server;
use strict;

use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;
require AutoLoader;

@ISA = qw(Exporter AutoLoader);
# Items to export into callers namespace by default.
@EXPORT = qw(
	
);
$VERSION = '1.7.1202.0';

require Carp;
require LWP::UserAgent;

# @ISA defines which classes our class inherits from
@ISA = qw( Exporter );

# This class does not export any symbols by default
# (that would be in @EXPORT). Instead, export
# the methods only on demand.
@EXPORT_OK = qw( post_action );

sub new
{
  my $self =  {};

  $self->{ua} = LWP::UserAgent->new;
  $self->{user} = 'root';
  $self->{pass} = '';
  $self->{admin} = 'admin';
  $self->{server} = 'localhost';
  $self->{port} = '9999';

  bless $self;

  return $self;
}

#
# username for Basic Authentication
#
sub user 
{
  my $self = shift;

  if (@_)
  {
    $self->{user} = shift;
  }

  return $self->{user};
}

#
# password for Basic Authentication
#
sub pass
{
  my $self = shift;

  if (@_)
  {
    $self->{pass} = shift;
  }

  return $self->{pass};
}

#
# location of the admin section
#
sub admin
{
  my $self = shift;

  if (@_)
  {
    $self->{admin} = shift;
  }

  return $self->{admin};
}

#
# server
#
sub server
{
  my $self = shift;

  if (@_)
  {
    $self->{server} = shift;
  }

  return $self->{server};
}

#
# port
#
sub port
{
  my $self = shift;

  if (@_)
  {
    $self->{port} = shift;
  }

  return $self->{port};
}

sub server_port
{
  my $self = shift;
  my $server;
  my $port;

  if (@_)
  {

    $server = $_[0];
    $server =~ s/(.*)(\:)(.*)/$1/;

    $port = $_[0];
    $port =~ s/(.*)(\:)(.*)/$3/;

  }

  return $self->server($server).':'.$self->port($port);
}

sub post_action
{
  my $self = shift;

  @_ == 1 or Carp::croak('usage: post_action [action] <[parameters]>');

  my $action = $_[0];
  my $parameters = $_[1];
  my $adminurl = 'http://'.$self->server().':'.$self->port().'/'.$self->admin().'/';

  my $responsetext = ""; # "Posting to ".$adminurl." ...\n";
  my $request;

  $request = HTTP::Request->new(POST => $adminurl);
  $request->content('action='.$action.$parameters);
  $request->content_type('application/x-www-form-urlencoded');
  $request->authorization_basic($self->user(), $self->pass());

  my $response = $self->{ua}->request($request);

  if ($response->is_success) {
    my $responsexml = $response->header('serverresponsexml');
    $responsetext = $responsetext.$responsexml;
    $responsetext =~ s/(.*<message>)(.*)(<\/message>.*)/$2/;
  } else {
    $responsetext = $responsetext."An error has occurred.\n".$response->code." ".$response->message;
  }

  return $responsetext;
}

sub get_url
{
  my $self = shift;

  @_ == 1 or Carp::croak('usage: get_url [url]');

  my $adminurl = 'http://'.$self->server().':'.$self->port().'/'.$self->admin().'/'.$_[0];

  my $responsetext = ""; # "Browsing to ".$adminurl." ...\n";
  my $request;

  $request = HTTP::Request->new(GET => $adminurl);
  $request->authorization_basic($self->user(), $self->pass());

  my $response = $self->{ua}->request($request);

  if ($response->is_success) {
    $responsetext = $responsetext.$response->content;
    $responsetext =~ s/&nbsp;/ /g;
    $responsetext =~ s/<\?xml version='1.0' \?>//g;
  } else {
    $responsetext = $responsetext."An error has occurred.\n".$response->code." ".$response->message;
  }

  return $responsetext;
}

__END__
