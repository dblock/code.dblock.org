#!/usr/bin/perl

BEGIN { $| = 1; print "Alkaline::Server ... "; }
END { print "failed\n" unless $loaded; }
use Alkaline::Server;
$loaded = 1;
print "ok\n";

